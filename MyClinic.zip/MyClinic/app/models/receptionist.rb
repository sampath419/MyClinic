class Receptionist < User
end
